﻿namespace Infrastructure.Entities
{
    public enum TaskStatus
    {
        Free,
        Work,
        Pause,
        Blocked,
        Completed
    }
}