﻿using BuisnnesService.Models;
using FluentValidation;

namespace TaskTrackerAPI.Validators.User
{
    public class UserLoginDtoValidator : AbstractValidator<UserLoginDto>
    {
        public UserLoginDtoValidator()
        {

            RuleFor(x => x.Email).NotEmpty().EmailAddress(FluentValidation.Validators.EmailValidationMode.AspNetCoreCompatible).WithMessage("Почта задана не корректно");
            RuleFor(x => x.Password).NotEmpty().MinimumLength(5).WithMessage("Минимальная длинна пароля 5 символов")
                .Must(PasswordValidator)
                .WithMessage("Пароль должен иметь хотя бы одну букву в верхнем и нижнем регистре");
        }
        public static bool PasswordValidator(string password)
        {
            if (string.IsNullOrWhiteSpace(password)) return false;
            return password != password.ToLower() && password != password.ToUpper();
            
         }
    }
}
