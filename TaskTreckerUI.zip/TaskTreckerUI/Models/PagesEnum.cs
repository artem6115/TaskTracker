﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskTrackerUI.Models
{
    public enum PagesEnum
    {
        Main,
        Notify,
        Project,
        Task,
        Note,
        Setting,

    }
}
