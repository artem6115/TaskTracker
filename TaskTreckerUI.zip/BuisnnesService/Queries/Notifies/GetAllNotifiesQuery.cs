﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuisnnesService.Queries.Notifies
{
    public class GetAllNotifiesQuery : IRequest<List<Notify>>
    {
    }
}
