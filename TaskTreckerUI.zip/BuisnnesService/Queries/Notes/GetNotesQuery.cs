﻿

namespace BuisnnesService.Queries.Notes
{
    public class GetNotesQuery : IRequest<List<NoteDto>>
    {
    }
}
